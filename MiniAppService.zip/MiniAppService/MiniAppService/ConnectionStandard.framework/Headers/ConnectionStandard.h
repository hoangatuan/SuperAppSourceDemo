//
//  ConnectionStandard.h
//  ConnectionStandard
//
//  Created by Digilife on 22/08/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for ConnectionStandard.
FOUNDATION_EXPORT double ConnectionStandardVersionNumber;

//! Project version string for ConnectionStandard.
FOUNDATION_EXPORT const unsigned char ConnectionStandardVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConnectionStandard/PublicHeader.h>


