//
//  MiniAppService.h
//  MiniAppService
//
//  Created by Hoang Anh Tuan on 22/08/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for MiniAppService.
FOUNDATION_EXPORT double MiniAppServiceVersionNumber;

//! Project version string for MiniAppService.
FOUNDATION_EXPORT const unsigned char MiniAppServiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MiniAppService/PublicHeader.h>


