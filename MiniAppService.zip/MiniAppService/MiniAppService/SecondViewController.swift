//
//  SecondViewController.swift
//  MiniAppService
//
//  Created by Hoang Anh Tuan on 22/08/2021.
//

import UIKit

class SecondViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

