//
//  FirstViewController.swift
//  MiniAppService
//
//  Created by Hoang Anh Tuan on 22/08/2021.
//

import UIKit

class FirstViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .yellow
    }
    
    @IBAction func goToVC2(_ sender: Any) {
        let sb = UIStoryboard(name: "Main", bundle: Bundle(for: LauncherService.self))
        let vc = sb.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        navigationController?.pushViewController(vc, animated: true)
    }
}
