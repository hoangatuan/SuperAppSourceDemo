//
//  LauncherService.swift
//  MiniAppService
//
//  Created by Hoang Anh Tuan on 22/08/2021.
//

import UIKit
import ConnectionStandard

public class LauncherService: ConnectionStandard {
    public required init() {
        debugPrint("Init Launcher Service")
    }
    
    public func createInputViewController() -> UIViewController? {
        let sb = UIStoryboard(name: "Main", bundle: Bundle(for: LauncherService.self))
        let vc = sb.instantiateViewController(withIdentifier: "FirstViewController") as! FirstViewController
        return vc
    }
}
