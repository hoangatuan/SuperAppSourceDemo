//
//  ConnectionStandard.swift
//  ConnectionStandard
//
//  Created by Hoang Anh Tuan on 22/08/2021.
//

import UIKit

// Define standard interface for all mini apps
public protocol ConnectionStandard {
    init()
    func createInputViewController() -> UIViewController?
}

