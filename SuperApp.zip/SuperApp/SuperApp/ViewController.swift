//
//  ViewController.swift
//  SuperApp
//

import UIKit
import ConnectionStandard

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func openMiniApp(_ sender: Any) {
        // 1. Init class by it's name
        guard let launcherClass = NSClassFromString("MiniAppService.LauncherService") as? ConnectionStandard.Type else {
            debugPrint("Init launcher class failed")
            return
        }
        
        if let miniAppInputView = launcherClass.init().createInputViewController() {
            navigationController?.pushViewController(miniAppInputView, animated: true)
        }
    }
}

